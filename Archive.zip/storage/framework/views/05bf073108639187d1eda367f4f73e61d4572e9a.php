<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <?php echo $__env->make('includes.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <link rel="stylesheet" href="<?php echo e(url('backend/css/styles.css')); ?>">
  <title>Login</title>
</head>
<body>
  <div class="d-md-flex align-items-center justify-content-center"  style="height: 100vh">
    <div class="bg" style="background-image: url('images/bg_1.jpg');"></div>
    <div class="contents">

      <div class="container">
        <div class="align-items-center justify-content-center">
          <div class="col-md-12">
            <div class="form-block mx-auto">
              <div class="text-center mb-5">
                <h3 class="text-uppercase">Login <strong>Admin</strong></h3>
              </div>
              <form action="<?php echo e(route('login')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php if(Session::get('fail')): ?>
                  <div class="text-danger text-center ">
                    <?php echo e(Session::get('fail')); ?>

                  </div>        
                <?php endif; ?>
                <div class="form-group first">
                  <input 
                    type="text" 
                    class="form-control" 
                    placeholder="username" 
                    name="username"
                  >
                  <div class=" alert-danger small text-center rounded-bottom"><?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <?php echo e($message); ?>

                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                </div>
                <div class="form-group last mb-3">
                  <input 
                  type="password" 
                  class="form-control" 
                  placeholder="Password" 
                  name="password"
                  >
                  <div class=" alert-danger small text-center rounded-bottom"><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <?php echo e($message); ?>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                </div>
                <input type="submit" value="Log In" class="btn btn-block py-2 btn-success">
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  
</body>
</html><?php /**PATH /home/customer/www/greeting.syariahrooms.com/public_html/resources/views/pages/admin/login.blade.php ENDPATH**/ ?>