<?php $__env->startSection('sidebar'); ?>
    <!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

        <!-- Sidebar - Brand -->
        <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
            <div class="sidebar-brand-text mx-3">SyariahRooms Adm</div>
        </a>

        <!-- Divider -->
        <hr class="sidebar-divider my-0">

        <!-- Nav Item - Dashboard -->
        <li class="nav-item">
            <a class="nav-link" href="/admin">
                <i class="fas fa-fw fa-tachometer-alt"></i>
                <span>Dashboard</span></a>
        </li>

        <li class="nav-item">
            <a class="nav-link" href="/admin/promo">
                <i class="fas fa-fw fa-hotel"></i>
                <span>Promo</span></a>
        </li>

        <li class="nav-item active">
            <a class="nav-link" href="/admin/travel">
                <i class="fas fa-fw fa-images"></i>
                <span>Tour Travel</span></a>
        </li>

        <li class="nav-item">
            <a class="nav-link" href="/admin/investment">
                <i class="fas fa-fw fa-dollar-sign"></i>
                <span>Investment</span></a>
        </li>


        <hr class="sidebar-divider">

        <!-- Sidebar Toggler (Sidebar) -->
        <div class="text-center d-none d-md-inline">
            <button class="rounded-circle border-0" id="sidebarToggle"></button>
        </div>

    </ul>
    <!-- End of Sidebar -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
<h1>Contents Manager (Travel)</h1>
    <a href="<?php echo e(route('travel.create')); ?>" class="btn btn-success mb-2">Add</a>
    <br>
    <div class="row">
        <div class="col-12">
            <table class="table table-bordered" id="laravel_crud">
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Title</th>
                        <th>Travel Code</th>
                        <th>Price</th>
                        <th>Description</th>
                        <th>Gambar</th>
                        <th>Created at</th>
                        <th colspan="2">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $travels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $travel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($travel->id); ?></td>
                        <td><?php echo e($travel->title); ?></td>
                        <td><?php echo e($travel->travel_code); ?></td>
                        <td><?php echo e($travel->price); ?></td>
                        <td><?php echo e($travel->description); ?></td>
                        <td><img src="<?php echo e(url('asset/img/', $travel->image)); ?>" alt="" width="200rem"></td>
                        <td><?php echo e(date('Y-m-d', strtotime($travel->created_at))); ?></td>
                        <td><a href="<?php echo e(route('travel.edit',$travel->id)); ?>" class="btn btn-primary">Edit</a></td>
                        <td>
                        <form action="<?php echo e(route('travel.destroy', $travel->id)); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-danger" type="submit">Delete</button>
                        </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php echo $travels->links(); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/customer/www/greeting.syariahrooms.com/public_html/resources/views/pages/admin/travel/view.blade.php ENDPATH**/ ?>